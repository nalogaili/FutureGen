// صفحة لوحة التحكم - عرض جميع الأدوات

import { GetServerSideProps } from 'next';
import { getSession } from 'next-auth/react';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { toast, Toaster } from 'react-hot-toast';

export default function AdminToolList({ tools: initialTools }: { tools: any[] }) {
  const [tools, setTools] = useState(initialTools);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.sessionStorage.getItem('tool-updated')) {
      toast.success('✅ تم تعديل الأداة بنجاح');
      window.sessionStorage.removeItem('tool-updated');
    }
  }, []);

  const handleDelete = async (id: string) => {
    const confirmed = confirm('هل أنت متأكد أنك تريد حذف هذه الأداة؟');
    if (!confirmed) return;

    const res = await fetch(`/api/tools/${id}`, { method: 'DELETE' });
    if (res.ok) {
      toast.success('✅ تم حذف الأداة');
      setTools(tools.filter((tool) => tool.id !== id));
    } else {
      toast.error('❌ فشل الحذف');
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6">
      <Toaster position="top-center" reverseOrder={false} />
      <h1 className="text-2xl font-bold mb-6">🛠️ لوحة التحكم - الأدوات</h1>

      <Link href="/admin/tools/new" className="mb-4 inline-block px-4 py-2 bg-green-600 text-white rounded">
        ➕ إضافة أداة جديدة
      </Link>

      <ul className="divide-y border rounded bg-white dark:bg-gray-800">
        {tools.map((tool) => (
          <li key={tool.id} className="p-4 flex justify-between items-center">
            <div>
              <h2 className="font-semibold text-lg">{tool.name}</h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">{tool.category}</p>
            </div>
            <div className="flex items-center gap-4">
              <Link
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  window.sessionStorage.setItem('tool-updated', '1');
                  window.location.href = `/admin/tools/edit/${tool.id}`;
                }}
                className="text-blue-600 hover:underline text-sm"
              >
                تعديل
              </Link>
              <button
                onClick={() => handleDelete(tool.id)}
                className="text-red-600 hover:underline text-sm"
              >
                حذف
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async ({ req }) => {
  const session = await getSession({ req });
  if (!session?.user?.email?.endsWith('@yourdomain.com')) {
    return { redirect: { destination: '/', permanent: false } };
  }

  const res = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/api/tools`);
  const tools = await res.json();

  return { props: { tools } };
};
