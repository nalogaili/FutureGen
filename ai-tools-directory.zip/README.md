# 🚀 AI Tools Directory (Production-Ready)

A modern, high-performance Next.js app for discovering and categorizing AI tools — inspired by FutureTools.io.

---

## 🧱 Tech Stack

- **Frontend:** React, Next.js, Tailwind CSS
- **Backend:** Next.js API routes, Prisma ORM
- **Database:** PostgreSQL via Supabase
- **Auth:** NextAuth.js (Google, GitHub)
- **Email:** Resend / SendGrid
- **Analytics:** Plausible
- **Deployment:** Vercel

---

## 📦 Installation

```bash
git clone https://github.com/your-username/ai-tools-directory.git
cd ai-tools-directory
npm install
```

---

## 🔐 Environment Variables

Create a `.env.local` file:

```env
DATABASE_URL="postgresql://your_user:your_pass@your_host:5432/your_db"
NEXTAUTH_SECRET="your-secret"
NEXTAUTH_URL="http://localhost:3000"

GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
RESEND_API_KEY=...
```

---

## 🛠 Setup

```bash
npx prisma db push
npx prisma generate
npm run dev
```

---

## 📊 Admin Access

- Admin tools page: `/admin/tools`
- Restricted to users with email domain: `@yourdomain.com`
- Change logic in `pages/admin/tools.tsx`

---

## 📬 Sending Email Notifications

- Integrates Resend (or SendGrid)
- Sends on tool submission (if enabled via API route)

---

## 🌐 Production Deployment (Vercel)

- Push to GitHub
- Connect to Vercel
- Add environment variables
- Set build command: `npm run build`
- Set output: `.next`

---

## ⚙️ Utilities

### Dummy Data

```bash
node tools/scraper.js
```

### Sitemap

Auto-generated at `/sitemap.xml`

---

## 📄 License

MIT
