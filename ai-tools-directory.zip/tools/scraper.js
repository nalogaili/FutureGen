
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const dummyTools = [
  {
    name: 'ChatWizard',
    description: 'AI assistant for automated chat support.',
    category: 'Chatbot',
    platform: 'Web',
    modelType: 'GPT-4',
    price: 'Free',
    tags: 'chat,support,gpt',
  },
  {
    name: 'VisionGenie',
    description: 'Generate images from text prompts using AI.',
    category: 'Image Generation',
    platform: 'Web',
    modelType: 'DALL·E',
    price: 'Freemium',
    tags: 'image,creative,drawing',
  },
  {
    name: 'CodeSynth',
    description: 'Code generation and refactoring assistant.',
    category: 'Developer Tools',
    platform: 'VSCode Extension',
    modelType: 'Codex',
    price: 'Paid',
    tags: 'code,developer,automation',
  },
  {
    name: 'Transcripto',
    description: 'AI tool for audio-to-text transcription.',
    category: 'Audio',
    platform: 'Web, Mobile',
    modelType: 'Whisper',
    price: 'Free',
    tags: 'audio,transcription,voice',
  }
];

async function insertDummyTools() {
  for (const tool of dummyTools) {
    const exists = await prisma.tool.findFirst({ where: { name: tool.name } });
    if (!exists) {
      await prisma.tool.create({ data: tool });
    }
  }
  console.log(`Dummy tools inserted.`);
  await prisma.$disconnect();
}

insertDummyTools();
